import 'package:flutter/material.dart';

const Color PrimaryColor = Colors.blueGrey;