class Service {
  final String code;
  final String title;
  final int duration;

  Service({required this.code, required this.title, required this.duration});
}